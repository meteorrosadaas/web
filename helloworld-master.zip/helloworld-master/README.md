[![](https://godoc.org/github.com/giantswarm/helloworld?status.svg)](http://godoc.org/github.com/giantswarm/helloworld)
[![](https://img.shields.io/docker/pulls/giantswarm/helloworld.svg)](https://hub.docker.com/r/giantswarm/helloworld/)
[![Go Report Card](https://goreportcard.com/badge/github.com/giantswarm/helloworld)](https://goreportcard.com/report/github.com/giantswarm/helloworld)

# Hello World

A minimal web application to test your Giant Swarm setup.

To learn more about Giant Swarm, visit https://www.giantswarm.io/.
